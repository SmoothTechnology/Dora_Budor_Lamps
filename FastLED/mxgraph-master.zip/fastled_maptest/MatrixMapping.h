int xSize = 10;
int ySize = 10;
int maxLEDList = 8;
int LEDMap[10][10][8];


